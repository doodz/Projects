namespace YggClientCore.Categories
{
    public enum Categories
    {
        Movies,
        Music,
        Application,
        VideoGame,
        eBook,
        Emulation,
        Gps,
        XXX
    }
}