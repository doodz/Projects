namespace YggClientCore.Categories
{
    public class SubCategory : BaseCategory
    {
        public SubCategory(Categories typeCategorie) : base(typeCategorie)
        {
        }
    }
}