﻿namespace YggClientCore.Global
{
    public static class GlobalLocal
    {

        public static string YggIndex = "https://yggtorrent.com";

    }
}
